var express = require('express');
var port = 2512;
var app = express();
var bodyparser = require('body-parser'); //send and receive JSON, Image
var fs = require('fs');

app.use(bodyparser.json())  //send or receive from before GET function calls
app.use(bodyparser.urlencoded(
    {
        extended: false //make use of only array or string not some structure less objects
    }
))

//console.log(_dirname);

app.use(express.static("/media/vishal/E741C12520920552/Full Stack/B2G/" + "/public"));

app.set('view engine', 'ejs')
app.engine('html', require('ejs').renderFile)

app.get('/',  function(request, respose){
    respose.render('index.html')
})



app.listen(port, function(){
    console.log('Server is running in ' +port);
});