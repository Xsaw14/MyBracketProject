var xVal = document.getElementById('section_x');
var yVal = document.getElementById('section_y');
var resVal = document.getElementById('result');
var form = document.getElementById('form');

form.addEventListener('submit', function(event){
    if(!xVal.value || !yVal.value){
        alert("Please enter some values")
    }else{
        resVal.innerHTML = "Answer: "+(parseFloat(xVal.value)/parseFloat(yVal.value))*100 +" %";
    }
    event.preventDefault();
})
