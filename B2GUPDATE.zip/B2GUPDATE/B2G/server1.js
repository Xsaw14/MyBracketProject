var express = require('express');
var port = 2512;
var app = express();
var bodyparser = require('body-parser'); //send and receive JSON, Image
var fs = require('fs');
var data = [];
var mysql = require('mysql');
var mydefsql = require('./sql.js')

app.use(bodyparser.json())  //send or receive from before GET function calls
app.use(bodyparser.urlencoded(
    {
        extended: false //make use of only array or string not some structure less objects
    }
))

//console.log(_dirname);

app.use(express.static("D:/Full Stack 2/B2GUPDATE/B2G" + "/public"));

app.set('view engine', 'ejs')
app.engine('html', require('ejs').renderFile)

$.ajax({
    url: '/echo/json/',
    type: "post",
    dataType: "json",
    data: {
        json: JSON.stringify([
            {
            id: 1,
            firstName: "Peter",
            lastName: "Jhons"},
        {
            id: 2,
            firstName: "David",
            lastName: "Bowie"}
        ]),
        delay: 3
    },
    success: function(data, textStatus, jqXHR) {
        // since we are using jQuery, you don't need to parse response
        drawTable(data);
    }
});

function drawTable(data) {
    for (var i = 0; i < data.length; i++) {
        drawRow(data[i]);
    }
}

function drawRow(rowData) {
    var row = $("<tr />")
    $("#personDataTable").append(row); //this will append tr element to table... keep its reference for a while since we will add cels into it
    row.append($("<td>" + rowData.id + "</td>"));
    row.append($("<td>" + rowData.firstName + "</td>"));
    row.append($("<td>" + rowData.lastName + "</td>"));
}