var mysql = require('mysql');
module.exports.connectMySql = function () {
    return new Promise(function (resolve, reject) { 

    
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "P@$$word",
        database: "test"
    })

    /*con.connect(function(err){
        if(err)throw err;
        con.query("SELECT functionalities, (Sin_Sim_Min+Sin_Sim_Max)/2 as Sin_Sim, (Sin_Med_Min+Sin_Med_Max)/2 as Sin_Med,  (Sin_Com_Min+Sin_Com_Max)/2 as Sin_Com, (Mul_Sim_Min+Mul_Sim_Max)/2 as Mul_Sim, (Mul_Med_Min+Mul_Med_Max)/2 as Mul_Med,  (Mul_Com_Min+Mul_Com_Max)/2 as Mul_Com FROM test.b2gmaster", function(err, result, fields){
            if(err) throw err;
            return resolve(result);
    })
        console.log('writing here');
})*/
    con.connect(function(err){
        if (err) {
            console.log(err);
            return reject(err);
        } else {
            con.query("SELECT functionalities, (Sin_Sim_Min+Sin_Sim_Max)/2 as Sin_Sim, (Sin_Med_Min+Sin_Med_Max)/2 as Sin_Med,  (Sin_Com_Min+Sin_Com_Max)/2 as Sin_Com, (Mul_Sim_Min+Mul_Sim_Max)/2 as Mul_Sim, (Mul_Med_Min+Mul_Med_Max)/2 as Mul_Med,  (Mul_Com_Min+Mul_Com_Max)/2 as Mul_Com FROM test.b2gmaster", function (error_query, results_query) {
                if (error_query) {
                    console.log(error_query);
                    return reject(error_query);
                } else {
//                    con.release();
                    return resolve(results_query);
                }
            });
        } 
    })
})
}


