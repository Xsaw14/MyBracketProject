var mysql = require('mysql');

var data = [];

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "P@$$word",
    database: "test"
})

con.connect(function(err){
    if(err)throw err;
    con.query("SELECT functionalities, (Sin_Sim_Min+Sin_Sim_Max)/2 as Sin_Sim, (Sin_Med_Min+Sin_Med_Max)/2 as Sin_Med,  (Sin_Com_Min+Sin_Com_Max)/2 as Sin_Com, (Mul_Sim_Min+Mul_Sim_Max)/2 as Mul_Sim, (Mul_Med_Min+Mul_Med_Max)/2 as Mul_Med,  (Mul_Com_Min+Mul_Com_Max)/2 as Mul_Com FROM test.b2gmaster", function(err, result, fields){
        if(err) throw err;
        result.forEach(v=> {
            var tmp = {};
            tmp.func = v.functionalities
            tmp.sin_sim = v.Sin_Sim
            tmp.sin_med = v.Sin_Med
            tmp.sin_com = v.Sin_Com
            tmp.mul_sim = v.Mul_Sim
            tmp.mul_med = v.Mul_Med
            tmp.mul_com = v.Mul_Com
            data.push(tmp)
        })
        console.log(data);
    })
})

