$(document).ready(function(){
            $.get('http://localhost:2512/data',function(response) {
                // since we are using jQuery, you don't need to parse response
                drawTable(response);
            });
        }); 

        function drawTable(data) {
            for (var i = 0; i < data.length; i++) {
                drawRow(data[i], i, data.length);
                showDefault(i);
            }
        }

        function drawRow(rowData, indx, dataLength) {//rowData will have the array from get(/data) and indx is index of the array
            var row = $("<tr />")
            $("#myId").append(row);//this will append tr element to table... keep its reference for a while since we will add cels into it
            row.append($("<td>" + rowData.functionalities+ "</td>"));
            
            row.append($("<td><input id='single_" +indx+ "' type='checkbox'  onclick='showSomething(this)' /></td>"));
            row.append($("<td><input id='multi_" +indx+ "' type='checkbox' onclick='showSomething(this)' /></td>"));
            
            
            row.append($("<td><span id='simDefault_" +indx+ "'>0</span><span id='singleSimAvg_" +indx+ "' >" + rowData.Sin_Sim + "</span><span id='multiSimAvg_" +indx+ "' >" + rowData.Mul_Sim + "</span><span id='sumSim_" +indx+ "' >" + (rowData.Sin_Sim+rowData.Mul_Sim)  + "</span></td>"));
            
            row.append($("<td><span id='medDefault_" +indx+ "'>0</span><span id='singleMedAvg_" +indx+ "' >" + rowData.Sin_Med + "</span><span id='multiMedAvg_" +indx+ "' >" + rowData.Mul_Med + "</span><span id='sumMed_" +indx+ "' >" + (rowData.Sin_Med+rowData.Mul_Med)  + "</span></td>"));
            
            row.append($("<td><span id='comDefault_" +indx+ "'>0</span><span id='singleComAvg_" +indx+ "' >" + rowData.Sin_Com + "</span><span id='multiComAvg_" +indx+ "' >" + rowData.Mul_Com + "</span><span id='sumCom_" +indx+ "' >" + (rowData.Sin_Com+rowData.Mul_Com)  + "</span></td>"));
            
                
            
        }
        
        function showSomething(elm) {
            console.log("id is " + elm.id)
            const indx = elm.id.split('_')[1];
            console.log('index is ' + indx)
            
            const sinId = "single_" + indx;
            const mulId = "multi_" + indx;
            
            const sinSelected = $('#' + sinId).is(":checked");
            const mulSelected = $('#' + mulId).is(":checked");
            console.log('single selected: ' + sinSelected)
            console.log('multi selected: ' + mulSelected);
            if(sinSelected && mulSelected)  
                showBothPlans(indx);
            else if(sinSelected)
                showOnlySinglePlans(indx)
            else if(mulSelected)
                showOnlyMultiPlans(indx)
            else
                showDefault(indx)
        }
        
        function showDefault(indx) {
             document.getElementById('simDefault_'+ indx).style.display = "block";
             document.getElementById('medDefault_'+ indx).style.display = "block";
             document.getElementById('comDefault_'+ indx).style.display = "block";
            
            document.getElementById('singleSimAvg_'+ indx).style.display = "none";
             document.getElementById('singleMedAvg_'+ indx).style.display = "none";
             document.getElementById('singleComAvg_'+ indx).style.display = "none";
             document.getElementById('multiSimAvg_'+ indx).style.display = "none";
             document.getElementById('multiMedAvg_'+ indx).style.display = "none";
             document.getElementById('multiComAvg_'+ indx).style.display = "none";
             document.getElementById('sumSim_'+ indx).style.display = "none";
             document.getElementById('sumMed_'+ indx).style.display = "none";
             document.getElementById('sumCom_'+ indx).style.display = "none";
        }
            
        function showOnlySinglePlans(indx) {  
            console.log('gonna show single plans now for id: singleSimAvg_'+ indx );
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
            document.getElementById('singleSimAvg_'+ indx).style.display = "block";
             document.getElementById('singleMedAvg_'+ indx).style.display = "block";
             document.getElementById('singleComAvg_'+ indx).style.display = "block";
             document.getElementById('multiSimAvg_'+ indx).style.display = "none";
             document.getElementById('multiMedAvg_'+ indx).style.display = "none";
             document.getElementById('multiComAvg_'+ indx).style.display = "none";
             document.getElementById('sumSim_'+ indx).style.display = "none";
             document.getElementById('sumMed_'+ indx).style.display = "none";
             document.getElementById('sumCom_'+ indx).style.display = "none";
        }
            
        function showOnlyMultiPlans(indx) {    
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
             document.getElementById('singleSimAvg_'+ indx).style.display = "none";
             document.getElementById('singleMedAvg_'+ indx).style.display = "none";
             document.getElementById('singleComAvg_'+ indx).style.display = "none";
             document.getElementById('multiSimAvg_'+ indx).style.display = "block";
             document.getElementById('multiMedAvg_'+ indx).style.display = "block";
             document.getElementById('multiComAvg_'+ indx).style.display = "block";
             document.getElementById('sumSim_'+ indx).style.display = "none";
             document.getElementById('sumMed_'+ indx).style.display = "none";
             document.getElementById('sumCom_'+ indx).style.display = "none";
        }
            
        function showBothPlans(indx) {    
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
             document.getElementById('singleSimAvg_'+ indx).style.display = "none";
             document.getElementById('singleMedAvg_'+ indx).style.display = "none";
             document.getElementById('singleComAvg_'+ indx).style.display = "none";
             document.getElementById('multiSimAvg_'+ indx).style.display = "none";
             document.getElementById('multiMedAvg_'+ indx).style.display = "none";
             document.getElementById('multiComAvg_'+ indx).style.display = "none";
             document.getElementById('sumSim_'+ indx).style.display = "block";
             document.getElementById('sumMed_'+ indx).style.display = "block";
             document.getElementById('sumCom_'+ indx).style.display = "block";
        }