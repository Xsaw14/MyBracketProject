function generate(){
            let simCalc = 0;
            let medCalc = 0;
            let comCalc = 0;
            
            let trTag = table.getElementsByTagName('tr');
            
            for(let trObt of trTag){
                let elementId = trObt.id;
                if(elementId.includes('sim') && (trObt.style.display.localeCompare("block")==0){
                    simCalc = simCalc + +trObt.innerText;
                }
            }
            
            /*$("tr[id*='sim']").each(function (i, el) {
                //It'll be an array of elements
                console.log(el.innerHTML);
                if($(el).css("display")=="block"){
                    simCalc = simCalc + +el.innerText;
                }
            });*/
            /*$("tr[id^='med']").each(function (i, el) {
                //It'll be an array of elements
                if($(el).css("display")=="block"){
                    medCalc = simCalc + +el.innerText;
                }
            });
            $("tr[id^='com']").each(function (i, el) {
                //It'll be an array of elements
                if($(el).css("display")=="block"){
                    comCalc = simCalc + +el.innerText;
                }
            });
            console.log("simple = "+simCalc)
            console.log("Medium = "+medCalc)
            console.log("simple = "+simCalc)*/
        }
                   }