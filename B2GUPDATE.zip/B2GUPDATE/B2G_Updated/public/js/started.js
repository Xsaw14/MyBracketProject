$(document).ready(function(){
            $.get('http://localhost:2512/data',function(response) {
                // since we are using jQuery, you don't need to parse response
                drawTable(response);
            });
        }); 

        function drawTable(data) {
            for (var i = 0; i < data.length; i++) {
                drawRow(data[i], i, data.length);
                showDefault(i);
            }
        }
        
        function generate(){
            let simCalc = 0;
            let medCalc = 0;
            let comCalc = 0;
            
            let trTag = document.getElementsByTagName('span');
            
            for(let trObt of trTag){
                console.log("id = "+trObt.id)
                let elementId = trObt.id;
                let elementStylr = trObt.style.display;
                if(elementId.includes('sim') && (elementStylr.localeCompare('block')==0)){
                    console.log("Inside style checl")
                    simCalc = simCalc + +trObt.innerText;
                }
                if(elementId.includes('med') && (elementStylr.localeCompare('block')==0)){
                    console.log("Inside style checl")
                    medCalc = medCalc + +trObt.innerText;
                }
                if(elementId.includes('com') && (elementStylr.localeCompare('block')==0)){
                    console.log("Inside style checl")
                    comCalc = comCalc + +trObt.innerText;
                }
            }
            
            document.getElementById("totalSimple").innerHTML = simCalc;
            document.getElementById("totalMedium").innerHTML = medCalc;
            document.getElementById("totalComplex").innerHTML = comCalc;
            
            document.getElementById("totalSimpleValue").innerHTML = simCalc*20;
            document.getElementById("totalMediumValue").innerHTML = medCalc*35;
            document.getElementById("totalComplexValue").innerHTML = comCalc*60;
            
            let effort = Math.round(((simCalc*20)+(medCalc*35)+(comCalc*60))/60);
            console.log("effort = "+effort)
            
            document.getElementById("totalEffortinHours").innerHTML = effort;
            document.getElementById("totalEffortinHoursPerPerson").innerHTML = Math.round(effort/8);
            document.getElementById("totalEffortinHoursPerPerson_1").innerHTML = Math.round(effort/8);
            
            let totalvalue = +document.getElementById("totalRequirementAnalysis").innerHTML + +document.getElementById("totalTestDesign").innerHTML + +document.getElementById("totalEffortinHoursPerPerson_1").innerHTML + +document.getElementById("totalTestClosure").innerHTML
            document.getElementById("totalEffort_1").innerHTML = totalvalue;
            
            /*$("tr[id*='sim']").each(function (i, el) {
                //It'll be an array of elements
                console.log(el.innerHTML);
                if($(el).css("display")=="block"){
                    simCalc = simCalc + +el.innerText;
                }
            });*/
            /*$("tr[id^='med']").each(function (i, el) {
                //It'll be an array of elements
                if($(el).css("display")=="block"){
                    medCalc = simCalc + +el.innerText;
                }
            });
            $("tr[id^='com']").each(function (i, el) {
                //It'll be an array of elements
                if($(el).css("display")=="block"){
                    comCalc = simCalc + +el.innerText;
                }
            });*/
            console.log("simple = "+simCalc)
            console.log("Medium = "+medCalc)
            console.log("complex = "+comCalc)
            }

        function drawRow(rowData, indx, dataLength) {//rowData will have the array from get(/data) and indx is index of the array
            var row = $("<tr />")
            $("#myId").append(row);//this will append tr element to table... keep its reference for a while since we will add cels into it
            row.append($("<td>" + rowData.functionalities+ "</td>"));
            
            row.append($("<td><input id='single_" +indx+ "' type='radio' name='b2g_"+indx+"'  onclick='showSomething(this)' /></td>"));
            row.append($("<td><input id='multi_" +indx+ "' type='radio' name='b2g_"+indx+"' onclick='showSomething(this)' /></td>"));
            
            
            row.append($("<td><span id='simDefault_" +indx+ "'>0</span><span id='simsingleSimAvg_" +indx+ "' >" + rowData.Sin_Sim + "</span><span id='simmultiSimAvg_" +indx+ "' >" + rowData.Mul_Sim + "</span><span id='simsumSim_" +indx+ "' >" + (rowData.Sin_Sim+rowData.Mul_Sim)  + "</span></td>"));
            
            row.append($("<td><span id='medDefault_" +indx+ "'>0</span><span id='medsingleMedAvg_" +indx+ "' >" + rowData.Sin_Med + "</span><span id='medmultiMedAvg_" +indx+ "' >" + rowData.Mul_Med + "</span><span id='medsumMed_" +indx+ "' >" + (rowData.Sin_Med+rowData.Mul_Med)  + "</span></td>"));
            
            row.append($("<td><span id='comDefault_" +indx+ "'>0</span><span id='comsingleComAvg_" +indx+ "' >" + rowData.Sin_Com + "</span><span id='commultiComAvg_" +indx+ "' >" + rowData.Mul_Com + "</span><span id='comsumCom_" +indx+ "' >" + (rowData.Sin_Com+rowData.Mul_Com)  + "</span></td>"));
            
                
            
        }
        
        function showSomething(elm) {
            console.log("id is " + elm.id)
            const indx = elm.id.split('_')[1];
            console.log('index is ' + indx)
            
            const sinId = "single_" + indx;
            const mulId = "multi_" + indx;
            
            const sinSelected = $('#' + sinId).is(":checked");
            const mulSelected = $('#' + mulId).is(":checked");
            console.log('single selected: ' + sinSelected)
            console.log('multi selected: ' + mulSelected);
            if(sinSelected && mulSelected)  
                showBothPlans(indx);
            else if(sinSelected)
                showOnlySinglePlans(indx)
            else if(mulSelected)
                showOnlyMultiPlans(indx)
            else
                showDefault(indx)
        }
        
        function showDefault(indx) {
             document.getElementById('simDefault_'+ indx).style.display = "block";
             document.getElementById('medDefault_'+ indx).style.display = "block";
             document.getElementById('comDefault_'+ indx).style.display = "block";
            
            document.getElementById('simsingleSimAvg_'+ indx).style.display = "none";
             document.getElementById('medsingleMedAvg_'+ indx).style.display = "none";
             document.getElementById('comsingleComAvg_'+ indx).style.display = "none";
             document.getElementById('simmultiSimAvg_'+ indx).style.display = "none";
             document.getElementById('medmultiMedAvg_'+ indx).style.display = "none";
             document.getElementById('commultiComAvg_'+ indx).style.display = "none";
             document.getElementById('simsumSim_'+ indx).style.display = "none";
             document.getElementById('medsumMed_'+ indx).style.display = "none";
             document.getElementById('comsumCom_'+ indx).style.display = "none";
        }
            
        function showOnlySinglePlans(indx) {  
            console.log('gonna show single plans now for id: simsingleSimAvg_'+ indx );
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
            document.getElementById('simsingleSimAvg_'+ indx).style.display = "block";
             document.getElementById('medsingleMedAvg_'+ indx).style.display = "block";
             document.getElementById('comsingleComAvg_'+ indx).style.display = "block";
             document.getElementById('simmultiSimAvg_'+ indx).style.display = "none";
             document.getElementById('medmultiMedAvg_'+ indx).style.display = "none";
             document.getElementById('commultiComAvg_'+ indx).style.display = "none";
             document.getElementById('simsumSim_'+ indx).style.display = "none";
             document.getElementById('medsumMed_'+ indx).style.display = "none";
             document.getElementById('comsumCom_'+ indx).style.display = "none";
        }
            
        function showOnlyMultiPlans(indx) {    
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
             document.getElementById('simsingleSimAvg_'+ indx).style.display = "none";
             document.getElementById('medsingleMedAvg_'+ indx).style.display = "none";
             document.getElementById('comsingleComAvg_'+ indx).style.display = "none";
             document.getElementById('simmultiSimAvg_'+ indx).style.display = "block";
             document.getElementById('medmultiMedAvg_'+ indx).style.display = "block";
             document.getElementById('commultiComAvg_'+ indx).style.display = "block";
             document.getElementById('simsumSim_'+ indx).style.display = "none";
             document.getElementById('medsumMed_'+ indx).style.display = "none";
             document.getElementById('comsumCom_'+ indx).style.display = "none";
        }
            
        function showBothPlans(indx) {    
             document.getElementById('simDefault_'+ indx).style.display = "none";
             document.getElementById('medDefault_'+ indx).style.display = "none";
             document.getElementById('comDefault_'+ indx).style.display = "none";
            
             document.getElementById('simsingleSimAvg_'+ indx).style.display = "none";
             document.getElementById('medsingleMedAvg_'+ indx).style.display = "none";
             document.getElementById('comsingleComAvg_'+ indx).style.display = "none";
             document.getElementById('simmultiSimAvg_'+ indx).style.display = "none";
             document.getElementById('medmultiMedAvg_'+ indx).style.display = "none";
             document.getElementById('commultiComAvg_'+ indx).style.display = "none";
             document.getElementById('simsumSim_'+ indx).style.display = "block";
             document.getElementById('medsumMed_'+ indx).style.display = "block";
             document.getElementById('comsumCom_'+ indx).style.display = "block";
        }