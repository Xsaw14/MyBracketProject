var express = require('express');
var port = 2512;
var app = express();
var bodyparser = require('body-parser'); //send and receive JSON, Image
var fs = require('fs');
var data = [];
var mysql = require('mysql');
var mydefsql = require('./sql.js')

app.use(bodyparser.json())  //send or receive from before GET function calls
app.use(bodyparser.urlencoded(
    {
        extended: false //make use of only array or string not some structure less objects
    }
))

//console.log(_dirname);

app.use(express.static("D:/Full Stack 2/B2GUPDATE/B2G_Updated/public"));

app.set('view engine', 'ejs')
app.engine('html', require('ejs').renderFile)

app.get('/',  function(request, respose){
//    connectMySql();
    respose.render('index.html')
})

app.get('/data',  function(request, respose){
    console.log('Data link is connected')
    mydefsql.connectMySql().then(function (results) {
        respose.status(200).send(results);
    })
        .catch(function (error) {
        respose.send(500).send(error);
    });
    
    
})



app.listen(port, function(){
    console.log('Server is running in ' +port);
});


function connectMySql(){
    return new Promise(function (resolve, reject) { 

    
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "P@$$word",
        database: "test"
    })

    con.connect(function(err){
        if(err)throw err;
        con.query("SELECT functionalities, (Sin_Sim_Min+Sin_Sim_Max)/2 as Sin_Sim, (Sin_Med_Min+Sin_Med_Max)/2 as Sin_Med,  (Sin_Com_Min+Sin_Com_Max)/2 as Sin_Com, (Mul_Sim_Min+Mul_Sim_Max)/2 as Mul_Sim, (Mul_Med_Min+Mul_Med_Max)/2 as Mul_Med,  (Mul_Com_Min+Mul_Com_Max)/2 as Mul_Com FROM test.b2gmaster", function(err, result, fields){
//            console.log(result);
            if(err) throw err;
            return resolve(result);
            /*.forEach(v=> {
                var tmp = {};
                tmp.func = v.functionalities
                tmp.sin_sim = v.Sin_Sim
                tmp.sin_med = v.Sin_Med
                tmp.sin_com = v.Sin_Com
                tmp.mul_sim = v.Mul_Sim
                tmp.mul_med = v.Mul_Med
                tmp.mul_com = v.Mul_Com
                data.push(tmp)
            })*/
    })
        console.log('writing here');
})
    })
}