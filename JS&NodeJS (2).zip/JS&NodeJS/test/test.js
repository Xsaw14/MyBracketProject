var rs = require('readline-sync');


var aNewNum = 30;
var aNewNumNum = 30;

console.log(aNewNum+aNewNumNum);
var name = rs.question('wWhat is your Name?');

console.log("Your name is " + name);