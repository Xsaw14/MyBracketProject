var print = function(thingtoPrint){
    console.log(thingtoPrint);
};

module.exports = print;