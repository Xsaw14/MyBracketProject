function my_function(){
var Excel;
Excel = new ActiveXObject("Excel.Application");
Excel.Visible = false;
return Excel.Workbooks.Open("C:/desktop/test_rates.xls").ActiveSheet.Cells(2,1).Value;
}

//where l is number of rows and i are columns...
var i=1;
var l=1;

do
{
a=my_function()

if (a!=null)
{
console.log(a);
i++;
}
else
{
l++;
i=1;
document.write("<br />");
}

b = my_function()
}while(a!=null || b!=null);