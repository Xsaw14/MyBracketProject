var express = require('express');
var port = 2512;
var app = express();
var bodyparser = require('body-parser'); //send and receive JSON, Image
var fs = require('fs');

app.use(bodyparser.json())  //send or receive from before GET function calls
app.use(bodyparser.urlencoded(
    {
        extended: false //make use of only array or string not some structure less objects
    }
))

fs.readFile('./index.html',function(err, html){
    if(err){
        console.log(err);
        return;
    }
    var server = app.get('',function(request,response){
        response.statusCode = 200;
        response.setHeader('Content-Type', 'text/html');
        response.write(html);
        response.end();
    })
})



app.listen(port, function(){
    console.log('Server is running in ' +port);
});